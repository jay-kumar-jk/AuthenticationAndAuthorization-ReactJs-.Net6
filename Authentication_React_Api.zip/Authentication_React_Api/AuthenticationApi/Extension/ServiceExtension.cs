﻿namespace WebApi.Extension
{
    public static class ServiceExtension
    {
        public static void ConfigureCors(this IServiceCollection services, IConfiguration configuration)
        {

            //var localHostUrl = configuration.GetValue<string>("LocalHostUrl");
            var frontEndUrl = configuration.GetValue<string>("FrontEndUrl");
            services.AddCors(options =>
            {
                options.AddPolicy("CorsPolicy",
                    builder => builder.WithOrigins(frontEndUrl)
                    .AllowAnyMethod()
                    .AllowAnyHeader()
                    .AllowCredentials());
            });
        }
    }
}
