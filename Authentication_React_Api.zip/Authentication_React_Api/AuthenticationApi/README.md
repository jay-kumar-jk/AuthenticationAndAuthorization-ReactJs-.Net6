# dotnet-6-jwt-authentication-api

.NET 6.0 - JWT Authentication API

Documentation at https://jasonwatmore.com/post/2021/12/14/net-6-jwt-authentication-tutorial-with-example-api
